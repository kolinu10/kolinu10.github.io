﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 14;
        let normal_battery_TextCircle_img_height = 21;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 20;
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_icon_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 14;
        let idle_battery_TextCircle_img_height = 21;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 20;
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_cal_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''

        let cc = 0
		
        let element_index = 0; 
            let element_count = 4;
        
        function click_PLUS() {
          element_index = (element_index + 1) % element_count;
          apply_content_switch();
        }
        
        function click_MINUS() {
          if (element_index == 0) {
          element_index = element_count - 1;
            } else {
          element_index = (element_index - 1) % element_count;
            }	
          apply_content_switch();
        }
    
        function apply_content_switch() {
    
            normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, element_index == 0);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
            Button_7.setProperty(hmUI.prop.VISIBLE, element_index == 0);
            

            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
            Button_8.setProperty(hmUI.prop.VISIBLE, element_index == 1);

            normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, element_index == 2);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
            normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);

            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 3);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
            normal_city_name_text.setProperty(hmUI.prop.VISIBLE, element_index == 3);
            Button_9.setProperty(hmUI.prop.VISIBLE, element_index == 3);
            };

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Samsung One 600.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Samsung One 600.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 291,
              y: 74,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 291,
              y: 354,
              src: 'alam.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 91,
              y: 289,
              w: 186,
              h: 186,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Samsung One 600.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 360,
              mode: 1,
              // radius: 93,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 384,
              image_array: ["weat_01.png","weat_02.png","weat_03.png","weat_04.png","weat_05.png","weat_06.png","weat_07.png","weat_08.png","weat_09.png","weat_10.png","weat_11.png","weat_12.png","weat_13.png","weat_14.png","weat_15.png","weat_16.png","weat_17.png","weat_18.png","weat_19.png","weat_20.png","weat_21.png","weat_22.png","weat_23.png","weat_24.png","weat_25.png","weat_26.png","weat_27.png","weat_28.png","weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 147,
              y: 342,
              font_array: ["act_00.png","act_01.png","act_02.png","act_03.png","act_04.png","act_05.png","act_06.png","act_07.png","act_08.png","act_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'act_12.png',
              unit_tc: 'act_12.png',
              unit_en: 'act_12.png',
              negative_image: 'act_11.png',
              invalid_image: 'act_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 184,
              // center_y: 382,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 74,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF75A9FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 184,
              center_y: 382,
              start_angle: -180,
              end_angle: 180,
              radius: 72,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF75A9FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 347,
              font_array: ["act_00.png","act_01.png","act_02.png","act_03.png","act_04.png","act_05.png","act_06.png","act_07.png","act_08.png","act_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 396,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 347,
              font_array: ["act_00.png","act_01.png","act_02.png","act_03.png","act_04.png","act_05.png","act_06.png","act_07.png","act_08.png","act_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'act_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 396,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 184,
              // center_y: 382,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 74,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF75A9FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 184,
              center_y: 382,
              start_angle: -180,
              end_angle: 180,
              radius: 72,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF75A9FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 347,
              font_array: ["act_00.png","act_01.png","act_02.png","act_03.png","act_04.png","act_05.png","act_06.png","act_07.png","act_08.png","act_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 396,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 275,
              y: 294,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 306,
              month_startY: 142,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 255,
              day_startY: 142,
              day_sc_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_tc_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_en_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 20,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 137,
              // end_angle: 43,
              // radius: 225,
              // line_width: 14,
              // line_cap: Rounded,
              // color: 0xFF75A9FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 137,
              end_angle: 43,
              radius: 218,
              line_width: 14,
              corner_flag: 0,
              color: 0xFF75A9FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              // radius: 208,
              // angle: 145,
              // char_space_angle: 0,
              // unit: 'bat_10.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'bat_00.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'bat_01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'bat_02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'bat_03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'bat_04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'bat_05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'bat_06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'bat_07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'bat_08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'bat_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 + 208,
                src: 'bat_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 208,
              src: 'bat_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str.png',
              center_x: 183,
              center_y: 96,
              x: 10,
              y: 82,
              start_angle: -150,
              end_angle: 151,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 58,
              font_array: ["act_00.png","act_01.png","act_02.png","act_03.png","act_04.png","act_05.png","act_06.png","act_07.png","act_08.png","act_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'act_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 107,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec.png',
              // center_x: 89,
              // center_y: 239,
              // x: 9,
              // y: 57,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 89,
              second_centerY: 239,
              second_posX: 9,
              second_posY: 57,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 193,
              hour_startY: 190,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'time_10.png',
              hour_unit_tc: 'time_10.png',
              hour_unit_en: 'time_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 325,
              minute_startY: 190,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 291,
              y: 74,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 291,
              y: 354,
              src: 'alam.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 184,
              // center_y: 382,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 74,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF75A9FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 184,
              center_y: 382,
              start_angle: -180,
              end_angle: 180,
              radius: 72,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF75A9FF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 347,
              font_array: ["act_00.png","act_01.png","act_02.png","act_03.png","act_04.png","act_05.png","act_06.png","act_07.png","act_08.png","act_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 396,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 275,
              y: 294,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 306,
              month_startY: 142,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 255,
              day_startY: 142,
              day_sc_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_tc_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_en_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 20,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 137,
              // end_angle: 43,
              // radius: 225,
              // line_width: 14,
              // line_cap: Rounded,
              // color: 0xFF75A9FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 137,
              end_angle: 43,
              radius: 218,
              line_width: 14,
              corner_flag: 0,
              color: 0xFF75A9FF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              // radius: 208,
              // angle: 145,
              // char_space_angle: 0,
              // unit: 'bat_10.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'bat_00.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'bat_01.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'bat_02.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'bat_03.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'bat_04.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'bat_05.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'bat_06.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'bat_07.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'bat_08.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'bat_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_battery_TextCircle_img_width / 2,
                pos_y: 240 + 208,
                src: 'bat_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 208,
              src: 'bat_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str.png',
              center_x: 183,
              center_y: 96,
              x: 10,
              y: 82,
              start_angle: -150,
              end_angle: 151,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 58,
              font_array: ["act_00.png","act_01.png","act_02.png","act_03.png","act_04.png","act_05.png","act_06.png","act_07.png","act_08.png","act_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'act_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 107,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 193,
              hour_startY: 190,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'time_10.png',
              hour_unit_tc: 'time_10.png',
              hour_unit_en: 'time_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 325,
              minute_startY: 190,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 89,
              second_centerY: 239,
              second_posX: 9,
              second_posY: 57,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 332,
              w: 100,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 47,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 196,
              y: 190,
              w: 100,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 190,
              w: 100,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 128,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 274,
              y: 282,
              w: 80,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 332,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 332,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 332,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 347,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                click_MINUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 240,
              y: 347,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                click_PLUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 325;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 208));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 208));
                  // alignment = RIGHT
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 325;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 208));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 208));
                  // alignment = RIGHT
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 0) / 2;
                  idle_battery_TextCircle_angleOffset = -idle_battery_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 184,
                      center_y: 382,
                      start_angle: -180,
                      end_angle: 180,
                      radius: 72,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF75A9FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 184,
                      center_y: 382,
                      start_angle: -180,
                      end_angle: 180,
                      radius: 72,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF75A9FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 137,
                      end_angle: 43,
                      radius: 218,
                      line_width: 14,
                      corner_flag: 0,
                      color: 0xFF75A9FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 184,
                      center_y: 382,
                      start_angle: -180,
                      end_angle: 180,
                      radius: 72,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF75A9FF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 137,
                      end_angle: 43,
                      radius: 218,
                      line_width: 14,
                      corner_flag: 0,
                      color: 0xFF75A9FF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

            if (cc ==0 ){
              
              normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
              Button_8.setProperty(hmUI.prop.VISIBLE, false);
  
              normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
              normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
  
              normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
              Button_9.setProperty(hmUI.prop.VISIBLE, false);

            cc = 1;
            }

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}